**Word comment 0**

30% requested masking / 5% noise: A0 Acc@1=58.08%, Acc@3=72.71%; B1=10.19%/27.86%. Realized masking=32.03%. Weight-variant path RBO range=0.93251–0.99115.

**Word comment 1**

Corrected primary panel replay: Acc@1=3.33%, Acc@3=12.33%; use Table_XVI_Panel_Results.csv for intervals. Recheck the abstract word count after author integration.

**Word comment 2**

R. sindensis is unresolved, not silently substituted. Sirel and Deveciler 2018 reassigns Turkish material to R. polatliensis. In Serra-Kiel et al. 2020 p.53, the adjacent morphological description is R. soldadensis; R. sindensis occurs in comparisons. Literature source records document the distinction.

**Word comment 3**

21 characters; 131 substantive values, 171 total coded values including 40 response tokens. Update Table II and any figure counts.

**Word comment 4**

Rules=708; scoring=494 (69.77%); character-only=10; empty mappings=204; non-scoring=214. Mapping records=540 (527 with a value); HIGH/MEDIUM/LOW=363/155/22.

**Word comment 5**

Use Table_IV_Rule_Inventory.csv, including two source-supported additional D cards; total rules are 708, not 706.

**Word comment 6**

RDF triples=9741; logical axioms=7098, comprising TBox 77 + RBox 4 + ABox 7017. OWL API used here is 3.4.3 bundled with Owlready2/HermiT, not 5.1.9; update the footnote. Restrictions/disjointness=3/1 (15 pairs); 4/4 negative controls detected.

**Word comment 7**

v31 snapshot audit (a–i)=0,0,3,0,28,28,7,11,0; current v32=0,0,4,0,20,2,0,0,0. The claimed v31 (g)=0 is unsupported by the archived masters. Category c is a polarity screen and category e remains a real encoding limitation; do not claim all nine categories are zero.

**Word comment 8**

sectionWarning is driven by a non-neutral CHR_21=OBLIQUE or TANGENTIAL plus observed mapped CHR_07/08/12/15/17. It lists affected rules, reports scoringChanged=false, and does not alter ranks; actual HTTP/browser test passed.

**Word comment 9**

Pseudolacazina_M4 uses ANY: any observed successful alternative gives MATCH; only observing and failing every alternative gives MISMATCH; otherwise NEUTRAL. Vertebralina_C2 separately uses ALL_OBSERVED to represent an adult-planispiral compound contradiction.

**Word comment 10**

Current actual application capture confirms scenario A: Ammodiscus, score 19, CONFIRMED_GENUS, 18 excluded genera. Figures 3–4 are fresh high-resolution screenshots with an actual HTTP scoring receipt.

**Word comment 11**

Table XII current rows: AGG 36/11/10/29/0/7-of-12; PORC 42/12/17/34/0/7-of-8; HYA 26/9/4/16/0/5-of-7; total 104/32/31/79/0/19-of-27. Columns are paths/unique-first/tied-first/shared-rank-top3/excluded/correct-confirmed.

**Word comment 12**

55 API tests and 7 evaluation regression tests pass. Ten CQ queries match the master-derived projections or actual TaxonProfile records on an isolated Neo4j Community database. Browser→HTTP→data→score→render verification passed, with no page errors.

**Word comment 13**

All 12,000 inputs / 24,000 paired evaluations were recomputed with seed 20261111. Replace the full table from Table_XIII_Monte_Carlo.csv, including realized masking/noise and intervals; the old masking percentages and deltas must not be retained.

**Word comment 14**

All seven ablations A1–A7 plus A0 were recomputed on 104 current paths and 150 corrected-normalization panels. Replace the entire table from Table_XIV_Ablations.csv; the old per-cell numbers are obsolete.

**Word comment 15**

All 33 settings are in Table_XV_All_33_Configurations.csv. Default path Acc@1/3=34.16%/58.45%; δ=1/2/3 yields 27/25/18 confirmations. τobs=3 gives coverage 78.8462% and Acc@1 29.8344%. Thresholds preserve rankings; use the full file for every weight and state count.

**Word comment 16**

Panel Acc@1/3=3.33%/12.33%, coverage=88.67%, rule exclusion=43.33%. Do not retain the old maximum neutral fraction 0.35; the current maximum is 0.50 (10 of 20 entries). Do not infer a monotonic relation from the old plot. Current normalization changes only 2 raw (value,state) tuples, promotes zero neutral states, differs from the legacy sheets in 496 entries across 130 panels and changes 14 displayed genera. Source-overlap limits remain.

**Word comment 17**

Historical raw lookup: 42 name records + 33 no-record names; one returned record is molluscan. Thus 41 usable foraminifer records and 34 names without a usable foraminifer AphiaID remain, including Idalina. Idalina authority and PBDB 1662 are verified; AphiaID 761200 is rejected. Planocamerinoides 848836 is unaccepted, accepted target Nummulites 520941. Only these two names were re-queried on 2026-11-12.

**Word comment 18**

Use the actual outcome tables, retaining the negative literature and VLM findings. No expert-reviewed study or independent thin-section accuracy estimate has been completed. Internal confirmation precision is 70.37%, below the proposed 85% target.

**Word comment 19**

Factual disclosure to consider: OpenAI Codex assisted with v32 code revisions, deterministic evaluations, source checks, browser verification and output packaging. Keep the earlier Claude disclosure if accurate. This package does not assert author approval of AI-generated edits.

**Word comment 20**

The five core profiles are Pseudolacazina oeztemueri, Alveolina haymanaensis, Discocyclina seunesi, Laffitteina erki and Orbitoclypeus haymanaensis. A0=0%/50% top-1/top-3, coverage 60%, exclusion 40%; B1=5.1553%/15.4658%, coverage 100%, exclusion 40%. Karsella is an out-of-core scored probe and R. sindensis is not scored because the reference-description conflict is unresolved. Sources mix original descriptions and redescriptions; these are development probes, not EXPERT_VERIFIED forms.
