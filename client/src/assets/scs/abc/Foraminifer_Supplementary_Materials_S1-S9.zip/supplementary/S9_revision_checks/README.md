# S9 — Normalization replay and decision-path audit

`Foraminifer_Supplementary_Material_S9.pdf` provides the readable supplement. The accompanying Word file includes the editable expert observation sheet. The independent expert protocol remains planned.

## Reproduce the analysis

Run from the extracted archive root with Node.js 24 and Python with NumPy. The analysis uses archived model responses and runs offline.

```sh
node reproduce/replay_v27.cjs
python reproduce/summarize_v27_replays.py
```

The first command verifies checksums for the manifest, controller, scorer, and panel images. It compares the reproduced normalized observations and scorer outputs with the archived results for all 150 panels. It then restores the 184 raw neutral-state flags with all other preprocessing retained. For the separate decision-path check it replays all 104 archived paths and masks CHR_10 = SIMPLE in each porcelaneous path containing that value.

The second command reproduces the paired differences and percentile intervals by resampling matched source/section clusters 2,000 times using seed 20261109. The article and reference-book cohorts are reported separately and pooled for description. The book overlaps the knowledge base.

## Files in `data/`

| File | Contents |
| --- | --- |
| `S9_panel_replays.json` | Paired outcomes for the 150 published panels |
| `S9_state_promotions.json` | The 184 reverted character entries |
| `S9_path_traces.json` | Baseline and sensitivity outcomes for 104 paths, with exact triggers for the excluded leaf genera |
| `S9_replay_summary.json` | Paired summary statistics and decision-path counts |
| `S9_paired_panel_metrics.csv` | Cohort-level estimates, paired differences, and uncertainty intervals |
| `S9_archived_api_test_summary.json` | Original test summary supplied in the integration package |

The scoring snapshot corresponds to the frozen manuscript version at commit `1e12fb5fc2c32e5d042f4f322c823c50dcda59b6`. The live demonstration can evolve independently. [Evaluated commit](https://github.com/datkanber/foraminifera-fossil/tree/1e12fb5fc2c32e5d042f4f322c823c50dcda59b6) · [Live application](https://geoknow.asrlab.cloud/)
