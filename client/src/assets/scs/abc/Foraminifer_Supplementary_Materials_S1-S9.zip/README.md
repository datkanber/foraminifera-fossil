# Supplementary Materials S1–S9

This archive accompanies the v27 manuscript on the foraminiferal identification ontology and decision-support model. The [supplementary index](supplementary/README.md) describes the supplied knowledge base, source-labeled panel evaluation, and internal tests.

Start with the [S9 guide](supplementary/S9_revision_checks/README.md) for the v27 normalization replay, the decision-path audit, and the blank expert observation sheet. S9 also contains the figures and tables referenced from the main manuscript.
