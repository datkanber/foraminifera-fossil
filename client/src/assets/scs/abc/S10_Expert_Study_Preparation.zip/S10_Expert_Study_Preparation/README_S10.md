# Supplementary Material S10 — Preparation records of the planned expert-input evaluation (Section VIII-G)

Status: preparation only. No expert has been assigned, no observation form has been completed,
and no reference genus has been verified. This package contains no observations, no reference
labels, no engine outputs for study material, and no participant information.

Contents

- `forms/EXP01/`, `forms/EXP02/` — blank confirmatory observation forms (offline HTML and Word),
  blank 21-character observation rows, and the observer-specific presentation orders of the
  reserved validation codes F001–F060. The codes are empty reservations; no material is assigned.
- `frozen_v29/` — the archived V29 implementations used for scoring: the A0 engine
  (`api/src/services/scoring.js` with `api/data/characters.json` and `api/data/rule_chr_mapping.json`)
  and the B1 eliminative comparator (`eval/engine_bridge.cjs`), with SHA-256 checksums in
  `version_lock.json`.
- `technical_checks/` — logs of the technical checks: 18 software tests on synthetic fixtures,
  an automated browser test of the offline form, the readiness record, and the analysis gate
  that refuses to run while no observer is confirmed. These are software checks, not study results.

Not included: the pilot preparation materials (P001–P010), whose form and manifest contain image
checksums that could link the codes to the published panels before the blinded exercise; coordinator
records; the reference-label key; and any participant or candidate information.

`SHA256SUMS.txt` lists checksums of every file in this package.
