# Supplementary Materials S1–S9

- **S1**: Knowledge-base genus/rule/character inventory and integrity audit; uncurated literature provenance explicitly marked
- **S2**: Live read-only competency-query executions; independent expected values only where derivable from master JSON
- **S3**: Supplied OWL ontology and JSON decision trees; not the missing original source DOCX
- **S4**: Actual prompt, controller, scoring snapshot and frozen execution configuration
- **S5**: Replacement source-labelled exploratory image panel; no expert review results
- **S6**: 104-path internal consistency and A1–A7 counterfactuals; not expert-sheet ablations
- **S7**: Image-level real VLM responses, scoring metrics, confidence and observability tables with within-panel uncertainty
- **S8**: Per-module and source-cohort results, exclusions and reproducibility checks
- **S9** — Paired normalization replay, exclusion traces for 104 internal paths, blank expert observation sheet, additional figures and tables. [S9 guide](S9_revision_checks/README.md)

The evaluation uses 150 published image panels with source genus labels. Independent expert observations were unavailable. S1 marks uncurated per-rule provenance, stratigraphic ranges, and authority fields.
